from time import sleep
from selenium.common import NoSuchElementException
from utils import BaseDriver


class DdiPage(object):
    #元素定位层
    def __init__(self):
        self.driver = BaseDriver.get_driver()
        self.login_button = ('xpath','/html/body/div[1]/main/div/nav/div[2]/div[3]/div/a/i')
        self.login_id = ('xpath','//*[@id="id_username"]')
        self.login_passwd = ('xpath', '//*[@id="id_password"]')
        self.login_btn = ('xpath','/html/body/main/div/form/button')
        #site
        self.site_add_btn = ('xpath', '/html/body/div[1]/main/div/div[2]/div[2]/div/a[1]')
        self.site_name = ('xpath', '//*[@id="id_name"]')
        self.site_slug = ('xpath', '//*[@id="id_slug"]')
        self.site_create_btn = ('xpath', '//*[@id="edit-form"]/form/div[5]/button[2]')
        #device
        self.device_name = ('xpath', '//*[@id="id_name"]')
        self.device_slug = ('xpath', '//*[@id="id_slug"]')
        self.device_create_btn = ('xpath', '//*[@id="edit-form"]/form/div[2]/button[2]')
        #manufacturer
        self.manufacturer_name = ('xpath', '//*[@id="id_name"]')
        self.manufacturer_slug = ('xpath', '//*[@id="id_slug"]')
        self.manufacturer_create_btn = ('xpath', '//*[@id="edit-form"]/form/div[2]/button[2]')
        #ModuleTypes
        self.module_type_select_btn = ('xpath', '//*[@id="edit-form"]/form/div[1]/div[2]/div/div[1]/div[1]')
        self.module_type_select_option = ('xpath', '//*[@id="edit-form"]/form/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]')
        self.module_type_name = ('xpath', '//*[@id="id_model"]')
        self.module_type_create_btn = ('xpath', '//*[@id="edit-form"]/form/div[3]/button[2]')
        self.module_error_path1 = ('xpath', '//*[@id="id_part_number"]')
        #DeviceTypes
        self.DeviceTypes_select_btn = ('xpath', '//*[@id="edit-form"]/form/div[1]/div[2]/div/div[1]')
        self.DeviceTypes_select_option = ('xpath', '//*[@id="edit-form"]/form/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]')
        self.DeviceTypes_name = ('xpath', '//*[@id="id_model"]')
        self.DeviceTypes_slug = ('xpath', '//*[@id="id_slug"]')
        self.DeviceTypes_create_btn = ('xpath', '//*[@id="edit-form"]/form/div[5]/button[2]')

    #login模块
    def find_login_button(self):
        return self.driver.find_element(self.login_button[0], self.login_button[1])
    def fine_login_id(self):
        return self.driver.find_element(self.login_id[0], self.login_id[1])
    def find_login_passwd(self):
        return self.driver.find_element(self.login_passwd[0], self.login_passwd[1])
    def find_login_btn(self):
        return self.driver.find_element(self.login_btn[0], self.login_btn[1])
    '''
    site
    '''
    def click_site_add_btn(self):
        return self.driver.find_element(self.site_add_btn[0], self.site_add_btn[1])
    def input_site_name(self):
        return self.driver.find_element(self.site_name[0], self.site_name[1])
    def input_site_slug(self):
        return self.driver.find_element(self.site_slug[0], self.site_slug[1])
    def click_site_create_btn(self):
        return self.driver.find_element(self.site_create_btn[0], self.site_create_btn[1])
    '''
    device
    '''
    def input_device_name(self):
        return self.driver.find_element(self.device_name[0], self.device_name[1])
    def input_device_slug(self):
        return self.driver.find_element(self.device_slug[0], self.device_slug[1])
    def click_device_create_btn(self):
        return self.driver.find_element(self.device_create_btn[0], self.device_create_btn[1])
    '''
    manufacturer
    '''
    def input_manufacturer_name(self):
        return self.driver.find_element(self.manufacturer_name[0], self.manufacturer_name[1])
    def input_manufacturer_slug(self):
        return self.driver.find_element(self.manufacturer_slug[0], self.manufacturer_slug[1])
    def click_manufacturer_create_btn(self):
        return self.driver.find_element(self.manufacturer_create_btn[0], self.manufacturer_create_btn[1])
    '''
    ModuleTypes
    '''
    def click_moduletype_select_btn(self):
        return self.driver.find_element(self.module_type_select_btn[0], self.module_type_select_btn[1])
    def click_moduletype_select_option(self):
        return self.driver.find_element(self.module_type_select_option[0], self.module_type_select_option[1])
    def input_moduletype_name(self):
        return self.driver.find_element(self.module_type_name[0], self.module_type_name[1])
    def click_moduletype_create_btn(self):
        return self.driver.find_element(self.module_type_create_btn[0], self.module_type_create_btn[1])

    def click_moduletype_error_1(self):
        return self.driver.find_element(self.module_error_path1[0], self.module_error_path1[1])
    '''
    DeviceTypes
    '''
    def click_DeviceTypes_select_btn(self):
        return self.driver.find_element(self.DeviceTypes_select_btn[0], self.DeviceTypes_select_btn[1])
    def click_DeviceTypes_select_option(self):
        return self.driver.find_element(self.DeviceTypes_select_option[0], self.DeviceTypes_select_option[1])
    def input_DeviceTypes_name(self):
        return self.driver.find_element(self.DeviceTypes_name[0], self.DeviceTypes_name[1])
    def input_DeviceTypes_slug(self):
        return self.driver.find_element(self.DeviceTypes_slug[0], self.DeviceTypes_slug[1])
    def click_DeviceTypes_create_btn(self):
        return self.driver.find_element(self.DeviceTypes_create_btn[0], self.DeviceTypes_create_btn[1])

class DdiCz(object):
    #操作层
    def __init__(self):
        self.ddi_cz = DdiPage()
    def click_ddi(self, user):
        self.ddi_cz.find_login_button().click()
        self.ddi_cz.fine_login_id().clear()
        self.ddi_cz.fine_login_id().send_keys(user)
        # self.ddi_cz.find_login_btn().click()
    def input_password(self, password):
        self.ddi_cz.find_login_passwd().clear()
        self.ddi_cz.find_login_passwd().send_keys(password)
        self.ddi_cz.find_login_btn().click()
        # try:
        #     print("登录成功")
        # Exception as e:
        #     print("登录失败")
    '''
    site
    '''
    def add_site(self):
        self.ddi_cz.click_site_add_btn().click()

    def send_sitename(self, site_name):
        self.ddi_cz.input_site_name().send_keys(site_name)
    def send_siteslug(self, site_slug):
        self.ddi_cz.input_site_slug().click()
        self.ddi_cz.input_site_slug().clear()
        self.ddi_cz.input_site_slug().send_keys(site_slug)

    def click_site_create_btn(self):
        try:
            self.ddi_cz.click_site_create_btn().click()
            print("创建站点成功")
        except NoSuchElementException as e:
            print(f"创建站点失败: {e}")
        except Exception as e:
            print(f"创建站点异常: {e}")
    '''
    device
    '''
    def send_devicename(self, device_name):
        self.ddi_cz.input_device_name().send_keys(device_name)

    def send_deviceslug(self, device_slug):
        self.ddi_cz.input_device_slug().click()
        self.ddi_cz.input_device_slug().clear()
        self.ddi_cz.input_device_slug().send_keys(device_slug)
        sleep(0.5)

    def click_device_create_btn(self):
        self.ddi_cz.click_device_create_btn().click()

    '''
    manufacturer
    '''
    def send_manufacturer_name(self, manufacturer_name):
        self.ddi_cz.input_manufacturer_name().send_keys(manufacturer_name)

    def send_manufacturer_slug(self, manufacturer_slug):
        self.ddi_cz.input_manufacturer_slug().click()
        sleep(0.5)
        self.ddi_cz.input_manufacturer_slug().clear()
        sleep(0.5)
        self.ddi_cz.input_manufacturer_slug().send_keys(manufacturer_slug)
        sleep(0.5)

    def click_manufacturer_create_btn(self):
        self.ddi_cz.click_manufacturer_create_btn().click()
        sleep(0.5)

    '''
    ModuleTypes
    '''

    def click_moduletype_select_btn(self):
        self.ddi_cz.click_moduletype_select_btn().click()
        sleep(0.5)

    def click_moduletype_select_option(self):
        self.ddi_cz.click_moduletype_select_option().click()
        sleep(0.5)
        self.ddi_cz.click_moduletype_error_1().click()
    def send_moduletype_name(self, moduletype_name):
        self.ddi_cz.input_moduletype_name().clear()
        self.ddi_cz.input_moduletype_name().send_keys(moduletype_name)
        sleep(0.5)

    def click_moduletype_create_btn(self):
        self.ddi_cz.click_moduletype_create_btn().click()
        sleep(0.5)

    '''
    devicetype
    '''

    def click_DeviceTypes_select_btn(self):
        self.ddi_cz.click_DeviceTypes_select_btn().click()
        sleep(0.5)

    def click_DeviceTypes_select_option(self):
        self.ddi_cz.click_DeviceTypes_select_option().click()
        sleep(0.5)

    def send_DeviceTypes_name(self, DeviceTypes_name):
        self.ddi_cz.input_DeviceTypes_name().send_keys(DeviceTypes_name)
        sleep(0.5)

    def send_DeviceTypes_slug(self, DeviceTypes_slug):
        self.ddi_cz.input_DeviceTypes_slug().click()
        sleep(0.5)
        self.ddi_cz.input_DeviceTypes_slug().clear()
        self.ddi_cz.input_DeviceTypes_slug().send_keys(DeviceTypes_slug)
        sleep(0.5)


    def click_DeviceTypes_create_btn(self):
        self.ddi_cz.click_DeviceTypes_create_btn().click()


'''
业务
'''
class DdiTask(object):
    #业务层
    def __init__(self):
        self.ddi_task = DdiCz()
        self.ddi_cz = DdiCz()

    def go_to_ddi(self, user, password):
        self.ddi_task.click_ddi(user)
        self.ddi_task.input_password(password)
    def go_to_new_domain(self, new_domain_url):
        self.ddi_task.ddi_cz.driver.get(new_domain_url)

    def go_to_add_site(self, site_name, site_slug):
        self.ddi_task.add_site()
        self.ddi_task.send_sitename(site_name)
        self.ddi_task.send_siteslug(site_slug)
        self.ddi_task.click_site_create_btn()

    def go_to_device_url(self, new_device_url):
        self.ddi_task.ddi_cz.driver.get(new_device_url)

    def go_to_add_device(self, device_name, device_slug):
        self.ddi_task.send_devicename(device_name)
        self.ddi_task.send_deviceslug(device_slug)
        self.ddi_task.click_device_create_btn()



    '''
    type
    '''
    def go_to_manufacturer_url(self, manufacturer_url):
        self.ddi_task.ddi_cz.driver.get(manufacturer_url)

    def go_to_add_manufacturer(self, manufacturer_name, manufacturer_slug):
        self.ddi_task.send_manufacturer_name(manufacturer_name)
        self.ddi_task.send_manufacturer_slug(manufacturer_slug)
        self.ddi_task.click_manufacturer_create_btn()


    def go_to_Module_url(self, Module_url):
        self.ddi_task.ddi_cz.driver.get(Module_url)

    def go_to_add_Module(self, module_type_name):
        self.ddi_task.click_moduletype_select_btn()
        self.ddi_task.click_moduletype_select_option()
        self.ddi_task.send_moduletype_name(module_type_name)
        self.ddi_task.click_moduletype_create_btn()

    def go_to_DeviceTypes_url(self, DeviceTypes_url):
        self.ddi_task.ddi_cz.driver.get(DeviceTypes_url)

    def go_to_add_DeviceTypes(self, DeviceTypes_name, DeviceTypes_slug):
        self.ddi_task.click_DeviceTypes_select_btn()
        self.ddi_task.click_DeviceTypes_select_option()
        self.ddi_task.send_DeviceTypes_name(DeviceTypes_name)
        self.ddi_task.send_DeviceTypes_slug(DeviceTypes_slug)
        self.ddi_task.click_DeviceTypes_create_btn()
